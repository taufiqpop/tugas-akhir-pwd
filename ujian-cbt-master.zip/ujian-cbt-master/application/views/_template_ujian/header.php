<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$title;?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?=base_url('assets/adminlte/bower_components/bootstrap/dist/css/bootstrap.min.css');?>">
  <link rel="stylesheet" href="<?=base_url('assets/adminlte/bower_components/font-awesome/css/font-awesome.min.css');?>">
  <link rel="stylesheet" href="<?=base_url('assets/adminlte/dist/css/AdminLTE.min.css');?>">
  <link rel="stylesheet" href="<?=base_url('assets/adminlte/dist/css/skins/skin-blue.min.css');?>">
  <link rel="stylesheet" href="<?=base_url('assets/css/ujian.css');?>">

  <!-- Javascript -->
  <script src="<?=base_url('assets/adminlte/bower_components/jquery/dist/jquery.min.js');?>"></script>
  <script src="<?=base_url('assets/js/jquery.countdown.min.js');?>"></script>
  <script src="<?=base_url('assets/js/sweetalert2.all.min.js');?>"></script>
  <script src="<?=base_url('assets/js/app.js');?>"></script>
  <script>
    var base_url = '<?=base_url();?>';
  </script>
</head>
<body class="hold-transition skin-blue layout-top-nav" oncontextmenu="return false;" style="-moz-user-select: none; cursor: default;">
<div class="wrapper">

  <header class="main-header">
    <?php require_once('menu.php');?>
  </header>
    <div class="content-wrapper">
      <div class="container">
        <section class="content-header">
          <h1>
            <?=$judul?>
          </h1>
          <ol class="breadcrumb">
            <li><a href=""><i class="fa fa-dashboard"></i> <?=$detil_soal->nama_ujian;?></a></li>
            <li><?=$detil_soal->kelas;?></li>
            <li><?=$judul;?></li>
          </ol>
        </section>
        <section class="content">