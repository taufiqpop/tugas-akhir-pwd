    <a href="<?=base_url();?>" class="logo">
      <span class="logo-mini"><b>C</b><b>B</b><b>T</b></span>
      <span class="logo-lg"><b>C</b>omputer <b>B</b>ased <b>T</b>est</span>
    </a>

    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?=base_url('assets/img/Pop.jpg');?>" class="user-image" alt="User Image">
              <span class="hidden-xs"><?=$this->session->nama;?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
                <img src="<?=base_url('assets/img/Pop.jpg');?>" class="img-circle" alt="User Image">

                <p><?=$this->session->nama;?><br>
                   <?=$this->session->nis;?><br>
                   <?=$this->session->kelas;?></p>
              </li>
              <li class="user-footer">
                <div>
                  <a href="<?=base_url('logout');?>" class="btn btn-danger btn-block btn-flat"><i class="fa fa-sign-out"></i> Keluar</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>

    </nav>