    </section>
  </div>

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>Copyright &copy; <?=date('Y');?> <a href="<?=base_url();?>">L200190085</a>.</strong>
  </footer>
</div>

<script src="<?=base_url('assets/adminlte/bower_components/bootstrap/dist/js/bootstrap.min.js');?>"></script>
<!-- <script src="<?=base_url('assets/adminlte/bower_components/fastclick/lib/fastclick.js');?>"></script> -->
<script src="<?=base_url('assets/adminlte/dist/js/adminlte.min.js');?>"></script>
<!-- <script src="<?=base_url('assets/adminlte/bower_components/jquery-slimscroll/jquery.slimscroll.min.js');?>"></script> -->
<script>
  $(document).ready(function(){
    setInterval(function() {
      var date = new Date();
      var h = date.getHours(), m = date.getMinutes(), s = date.getSeconds();
      h = ("0" + h).slice(-2);
      m = ("0" + m).slice(-2);
      s = ("0" + s).slice(-2);

      var time = h + ":" + m + ":" + s ;
      $('.live-clock').html(time);
    }, 1000);
  })
</script>
</body>
</html>
