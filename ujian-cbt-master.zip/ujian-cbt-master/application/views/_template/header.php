<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$title;?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?=base_url('assets/adminlte/bower_components/bootstrap/dist/css/bootstrap.min.css');?>">
  <link rel="stylesheet" href="<?=base_url('assets/adminlte/bower_components/font-awesome/css/font-awesome.min.css');?>">
  <link rel="stylesheet" href="<?=base_url('assets/adminlte/dist/css/AdminLTE.min.css');?>">
  <link rel="stylesheet" href="<?=base_url('assets/adminlte/dist/css/skins/_all-skins.min.css');?>">

  <!-- Javascript -->
  <script src="<?=base_url('assets/adminlte/bower_components/jquery/dist/jquery.min.js');?>"></script>
  <script src="<?=base_url('assets/js/sweetalert2.all.min.js');?>"></script>
</head>
<body class="hold-transition skin-blue fixed sidebar-mini" oncontextmenu="return false;" style="-moz-user-select: none; cursor: default;">
<div class="wrapper">

  <header class="main-header">
    <?php require_once('topmenu.php');?>
  </header>
    <?php require_once('sidebar.php');?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        <?=$judul;?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?=base_url();?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?=$judul;?></li>
      </ol>
    </section>
    <section class="content">