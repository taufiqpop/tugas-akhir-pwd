<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= $title;?> | Aplikasi Ujian Berbasis Komputer</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?= base_url('./../assets/adminlte/bower_components/bootstrap/dist/css/bootstrap.min.css');?>">
  <link rel="stylesheet" href="<?= base_url('./../assets/adminlte/bower_components/font-awesome/css/font-awesome.min.css');?>">
  <link rel="stylesheet" href="<?= base_url('./../assets/adminlte/dist/css/AdminLTE.min.css');?>">
  <link rel="stylesheet" href="<?= base_url('./../assets/adminlte/dist/css/skins/skin-blue.min.css');?>">
  <link rel="stylesheet" href="<?= base_url('./../assets/adminlte/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css');?>">
  <!-- <link rel="stylesheet" href="<?= base_url('./../assets/adminlte/bower_components/bootstrap-daterangepicker/daterangepicker.css');?>"> -->
  <!-- <link rel="stylesheet" href="<?= base_url('./../assets/adminlte/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css');?>">   -->
  <!-- <link rel="stylesheet" href="<?=base_url('./../assets/adminlte/bower_components/select2/dist/css/select2.min.css');?>"> -->
  <link rel="stylesheet" href="<?=base_url('./../assets/css/sweetalert2.min.css');?>">
  <link rel="stylesheet" href="<?=base_url('./../assets/css/style-admin.css');?>">
  <script src="<?= base_url('./../assets/adminlte/bower_components/jquery/dist/jquery.min.js');?>"></script>
  <script src="<?= base_url('./../assets/adminlte/bower_components/datatables.net/js/jquery.dataTables.min.js');?>"></script>
  <script src="<?= base_url('./../assets/adminlte/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js');?>"></script>
  <!-- <script src="<?= base_url('./../assets/adminlte/bower_components/jquery-ui/jquery-ui.min.js');?>"></script> -->
  <script src="<?=base_url('./../assets/js/sweetalert2.all.min.js');?>"></script>

</head>
<body class="hold-transition skin-blue sidebar-mini fixed">
<div class="wrapper">

  <header class="main-header">
    <a href="<?= base_url();?>" class="logo">
      <span class="logo-mini"><b>CBT</b></span>
      <span class="logo-lg"><b>C</b>omputer <b>B</b>ased <b>T</b>est</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?= base_url('./../assets/adminlte/dist/img/Admin.jpg');?>" class="user-image" alt="User Image">
              <span class="hidden-xs">
                <?=$this->session->nama;?>
              </span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
                <img src="<?= base_url('./../assets/adminlte/dist/img/Admin.jpg');?>" class="img-circle" alt="User Image">
                <p>
                  <?= $this->session->nama;?>
                </p>
              </li>
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?= base_url('setting');?>" class="btn btn-warning btn-flat"><i class="fa fa-gear"></i> Setting</a>
                </div>
                <div class="pull-right">
                  <a href="<?= base_url('admin/logout');?>" class="btn btn-danger btn-flat"><i class="fa fa-sign-out"></i> Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?= base_url('./../assets/adminlte/dist/img/Admin.jpg');?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?=$this->session->username;?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online (tapi cuma diread)</a>
        </div>
      </div>
      <ul class="sidebar-menu tree" data-widget="tree">
        <li class="header text-aqua">MENU NAVIGASI</li>
    <?php
      if($this->session->status == 'admin'){ ?>
        <li>
        <a href="<?= base_url('guru');?>"><i class="fa fa-users text-aqua"></i><span>Dosen</span></a>
        </li>
        <li>
        <a href="<?= base_url('mapel');?>"><i class="fa fa-clone text-aqua"></i><span>Mapel</span></a>
        </li>
        <li>
        <a href="<?= base_url('tsoal');?>"><i class="fa fa-list-alt text-aqua"></i><span>Tambah Soal</span></a>
        </li>
        <li class="treeview">
        <a href="#">
        <i class="fa fa-list text-aqua"></i> <span>Soal</span>
        <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
        </a>
          <ul class="treeview-menu">
            <?php foreach($perkelas as $pk){ ?>
            <li class="treeview">
              <a href="#"><i class="fa fa-circle-o"></i> Kelas <?=$pk->kelas;?> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
              <ul class="treeview-menu">
                <?php
                  $where = array('kelas' => $pk->kelas); 
                  $perkelasjurusan = $this->m_admin->perkelasjurusan($where)->result();
                  foreach($perkelasjurusan as $pkj){ ?>
                <li><a href="<?=base_url('soal/'.$pkj->id_kelas);?>"><?=$pkj->kode_kelas;?></a></li>
                <?php } ?>
              </ul>
            </li>
            <?php } ?>
          </ul>
        </li>
        <li class="treeview">
        <a href="#">
        <i class="fa fa-table text-aqua"></i> <span>Nilai</span>
        <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
        </a>
          <ul class="treeview-menu">
            <?php foreach($perkelas as $pk){ ?>
            <li class="treeview">
              <a href="#"><i class="fa fa-circle-o"></i> Kelas <?=$pk->kelas;?> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
              <ul class="treeview-menu">
                <?php
                  $where = array('kelas' => $pk->kelas); 
                  $perkelasjurusan = $this->m_admin->perkelasjurusan($where)->result();
                  foreach($perkelasjurusan as $pkj){ ?>
                <li><a href="<?= base_url('nilai/'.$pkj->id_kelas);?>"><i class="fa fa-circle-o"></i> <?=$pkj->kode_kelas;?></a></li>
                <?php } ?>
              </ul>
            </li>
            <?php } ?>
          </ul>
        </li>
        <li>
        <a href="<?= base_url('siswa');?>"><i class="fa fa-user text-aqua"></i><span>Siswa</span></a>
        </li>
        <li>
        <a href="<?= base_url('kelas');?>"><i class="fa fa-th text-aqua"></i><span>Kelas / Jurusan</span></a>
        </li>
        <li>
        <a href="<?= base_url('ujian');?>"><i class="fa fa-th-list text-aqua"></i><span>Ujian</span></a>
        </li>
    <?php } ?>
    <?php 
      if($this->session->status == 'guru'){ ?>
        <li>
        <a href="<?= base_url('tsoal');?>"><i class="fa fa-list-alt text-aqua"></i><span>Tambah Soal</span></a>
        </li>
        <li class="treeview">
        <a href="#">
        <i class="fa fa-list text-aqua"></i> <span>Soal</span>
        <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
        </a>
          <ul class="treeview-menu">
            <?php foreach($perkelas as $pk){ ?>
            <li class="treeview">
              <a href="#"><i class="fa fa-circle-o"></i> Kelas <?=$pk->kelas;?> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
              <ul class="treeview-menu">
                <?php
                  $perkelasjurusan = $this->m_admin->perkelasjurusan_g($pk->kelas, $this->session->id)->result();
                  foreach($perkelasjurusan as $pkj){ ?>
                <li><a href="<?=base_url('soal/'.$pkj->id_kelas);?>"><?=$pkj->kode_kelas;?></a></li>
                <?php } ?>
              </ul>
            </li>
            <?php } ?>
          </ul>
        </li>
        <li class="treeview">
        <a href="#">
        <i class="fa fa-table text-aqua"></i> <span>Nilai</span>
        <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
        </a>
          <ul class="treeview-menu">
            <?php foreach($perkelas as $pk){ ?>
            <li class="treeview">
              <a href="#"><i class="fa fa-circle-o"></i> Kelas <?=$pk->kelas;?> <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
              <ul class="treeview-menu">
                <?php
                  $perkelasjurusan = $this->m_admin->perkelasjurusan_g($pk->kelas, $this->session->id)->result();
                  foreach($perkelasjurusan as $pkj){ ?>
                <li><a href="<?= base_url('nilai/'.$pkj->id_kelas);?>"><i class="fa fa-circle-o"></i> <?=$pkj->kode_kelas;?></a></li>
                <?php } ?>
              </ul>
            </li>
            <?php } ?>
          </ul>
        </li>
    <?php } ?>
      </ul>
    </section>
  </aside>