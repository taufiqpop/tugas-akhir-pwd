<footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>Copyright &copy; <?= date('Y');?> <a href="#">L200190085</a>.</strong>
  </footer>

</div>
<script src="<?= base_url('./../assets/adminlte/bower_components/bootstrap/dist/js/bootstrap.min.js');?>"></script>
<!-- <script src="<?= base_url('./../assets/adminlte/bower_components/jquery-knob/dist/jquery.knob.min.js');?>"></script> -->
<!-- <script src="<?= base_url('./../assets/adminlte/bower_components/moment/min/moment.min.js');?>"></script>
<script src="<?= base_url('./../assets/adminlte/bower_components/bootstrap-daterangepicker/daterangepicker.js');?>"></script> -->
<script src="<?= base_url('./../assets/adminlte/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js');?>"></script>
<!-- <script src="<?= base_url('./../assets/adminlte/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js');?>"></script> -->
<!-- <script src="<?=base_url('./../assets/adminlte/bower_components/select2/dist/js/select2.full.min.js');?>"></script> -->
<script src="<?= base_url('./../assets/adminlte/bower_components/jquery-slimscroll/jquery.slimscroll.min.js');?>"></script>
<script src="<?= base_url('./../assets/adminlte/bower_components/fastclick/lib/fastclick.js');?>"></script>
<script src="<?= base_url('./../assets/adminlte/dist/js/adminlte.min.js');?>"></script>
</body>
</html>